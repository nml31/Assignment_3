//
//  ViewController.m
//  NML31NSURLConnection
//
//  Created by Landolfi, Nicholas M on 2/19/15.
//  Copyright (c) 2015 Landolfi, Nicholas M. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *webSite = @"http://www.google.com";
    NSURL *url = [NSURL URLWithString: webSite];
    NSURLRequest *request = [NSURLRequest requestWithURL: url];
    
    [webPage loadRequest: request];
}

-(IBAction)goToWebSite:(id)sender {
    
    NSString *newWebsite = [NSString stringWithFormat:@"http://%@", addressBar.text];
    
    NSURL *url = [NSURL URLWithString:newWebsite];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [webPage loadRequest:request];
    
    [addressBar resignFirstResponder];
}

-(IBAction)refresh:(id)sender {
    [webPage reload];
}

-(IBAction)goBack:(id)sender {
    [webPage goBack];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
