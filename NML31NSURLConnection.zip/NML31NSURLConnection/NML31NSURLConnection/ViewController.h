//
//  ViewController.h
//  NML31NSURLConnection
//
//  Created by Landolfi, Nicholas M on 2/19/15.
//  Copyright (c) 2015 Landolfi, Nicholas M. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIWebViewDelegate> {
    
    IBOutlet UIWebView *webPage;
    IBOutlet UITextField *addressBar;
    
}

-(IBAction)goToWebSite:(id)sender;
-(IBAction)refresh:(id)sender;
-(IBAction)goBack:(id)sender;


@end

